# TRY MIXER DIGITAL — Proyek Android

**Paket ini adalah proyek sumber Android Studio, bukan APK hasil kompilasi.**

## Cara membangun APK
1. Ekstrak ZIP ini.
2. Buka folder `TRY_MIXER_DIGITAL_Android` di Android Studio.
3. Tunggu Gradle Sync; pasang Android SDK 35 bila diminta.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug akan dibuat di `app/build/outputs/apk/debug/app-debug.apk`.
6. Kirim APK ke HP Android, lalu instal. Izinkan instalasi dari sumber yang digunakan bila Android memintanya.

## Fitur versi awal
- Tampilan landscape dengan judul TRY MIXER DIGITAL dan tombol MIXER ON/OFF.
- Pemutar YouTube di bagian atas, pencarian YouTube (membuka hasil pencarian), dan input link video.
- CH1, CH2, CH3; FX SEND 1, FX SEND 2, MASTER OUTPUT.
- Fader vertikal High/Mid/Low dan level channel.
- Tombol Reverb, Delay, Harmony, Vocal Remover, Pitch/Key beserta panel kontrol.
- Master, Vocal Output, dan Music Output.

## Batasan teknis
Pada versi awal ini fader dan efek adalah kontrol antarmuka; belum ada pemrosesan audio DSP sungguhan. Audio dari YouTube tidak otomatis masuk ke jalur mixer. DSP real-time membutuhkan mesin audio native Android serta sumber audio yang dapat diakses secara legal dan teknis.
